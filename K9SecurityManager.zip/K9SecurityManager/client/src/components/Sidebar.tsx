import { 
  BarChart3, 
  CheckSquare, 
  Settings, 
  Shield, 
  Ticket, 
  Users, 
  Server, 
  Gauge,
  AlertTriangle,
  FileText,
  TrendingUp
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

export default function Sidebar() {
  const [location] = useLocation();

  const navigationItems = [
    {
      section: "Security Management",
      items: [
        { 
          name: "Dashboard", 
          href: "/dashboard", 
          icon: Gauge, 
          active: location === "/" || location === "/dashboard" 
        },
        { 
          name: "Security Incidents", 
          href: "/incidents", 
          icon: AlertTriangle, 
          badge: "12",
          badgeColor: "bg-destructive",
          active: location.startsWith("/incidents") 
        },
        { 
          name: "ISMS Compliance", 
          href: "/compliance", 
          icon: CheckSquare, 
          active: location.startsWith("/compliance") 
        },
        { 
          name: "Service Requests", 
          href: "/service-requests", 
          icon: Ticket, 
          badge: "7",
          badgeColor: "bg-yellow-500",
          active: location.startsWith("/service-requests") 
        },
        { 
          name: "Asset Management", 
          href: "/assets", 
          icon: Server, 
          active: location.startsWith("/assets") 
        },
      ]
    },
    {
      section: "Reports & Analytics",
      items: [
        { 
          name: "Security Reports", 
          href: "/reports", 
          icon: FileText, 
          active: location.startsWith("/reports") 
        },
        { 
          name: "Risk Analytics", 
          href: "/analytics", 
          icon: TrendingUp, 
          active: location.startsWith("/analytics") 
        },
      ]
    },
    {
      section: "Administration",
      items: [
        { 
          name: "User Management", 
          href: "/users", 
          icon: Users, 
          active: location.startsWith("/users") 
        },
        { 
          name: "System Settings", 
          href: "/settings", 
          icon: Settings, 
          active: location.startsWith("/settings") 
        },
      ]
    },
  ];

  return (
    <aside className="bg-white w-64 shadow-sm border-r border-gray-200 overflow-y-auto">
      <nav className="mt-6 px-4">
        {navigationItems.map((section, sectionIdx) => (
          <div key={section.section} className={cn("space-y-2", sectionIdx > 0 && "mt-8")}>
            <div className="pb-4">
              <h3 className="text-xs font-semibold text-gray-600 uppercase tracking-wide">
                {section.section}
              </h3>
            </div>
            {section.items.map((item) => {
              const Icon = item.icon;
              return (
                <a
                  key={item.name}
                  href={item.href}
                  className={cn(
                    "group flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors",
                    item.active
                      ? "bg-primary text-primary-foreground"
                      : "text-gray-700 hover:bg-gray-100"
                  )}
                >
                  <Icon className="mr-3 h-4 w-4" />
                  {item.name}
                  {item.badge && (
                    <Badge 
                      className={cn(
                        "ml-auto text-white text-xs px-2 py-1",
                        item.badgeColor || "bg-destructive"
                      )}
                    >
                      {item.badge}
                    </Badge>
                  )}
                </a>
              );
            })}
          </div>
        ))}
      </nav>
    </aside>
  );
}
