import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CheckSquare, Plus, Eye, Edit, Calendar, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ComplianceFramework, ComplianceAssessment } from "@shared/schema";

export default function Compliance() {
  const [selectedFramework, setSelectedFramework] = useState<ComplianceFramework | null>(null);
  const [selectedAssessment, setSelectedAssessment] = useState<ComplianceAssessment | null>(null);
  const [showFrameworkDialog, setShowFrameworkDialog] = useState(false);
  const [showAssessmentDialog, setShowAssessmentDialog] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch compliance frameworks
  const { data: frameworks = [], isLoading: frameworksLoading } = useQuery<ComplianceFramework[]>({
    queryKey: ["/api/compliance-frameworks"],
  });

  // Fetch compliance assessments
  const { data: assessments = [], isLoading: assessmentsLoading } = useQuery<ComplianceAssessment[]>({
    queryKey: ["/api/compliance-assessments"],
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "in_progress": return "bg-yellow-100 text-yellow-800";
      case "planned": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getComplianceScore = (frameworkId: number) => {
    const frameworkAssessments = assessments.filter(
      a => a.frameworkId === frameworkId && a.status === "completed" && a.score
    );
    
    if (frameworkAssessments.length === 0) return 0;
    
    return Math.round(
      frameworkAssessments.reduce((sum, a) => sum + (a.score || 0), 0) / frameworkAssessments.length
    );
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div>
      {/* Page Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <nav className="flex mb-2" aria-label="Breadcrumb">
              <ol className="flex items-center space-x-2">
                <li className="text-gray-500 text-sm">Security Management</li>
                <li className="text-gray-500">/</li>
                <li className="text-gray-900 text-sm font-medium">ISMS Compliance</li>
              </ol>
            </nav>
            <h2 className="text-2xl font-semibold text-gray-900">ISMS Compliance</h2>
            <p className="text-gray-600 text-sm mt-1">Track and manage compliance with security frameworks</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              <TrendingUp className="mr-2 h-4 w-4" />
              View Trends
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Assessment
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="frameworks">Frameworks</TabsTrigger>
            <TabsTrigger value="assessments">Assessments</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Compliance Scores */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {frameworksLoading ? (
                <div className="col-span-3 text-center text-gray-500">Loading frameworks...</div>
              ) : frameworks.length === 0 ? (
                <div className="col-span-3 text-center text-gray-500">No frameworks found</div>
              ) : (
                frameworks.map((framework) => {
                  const score = getComplianceScore(framework.id);
                  return (
                    <Card key={framework.id}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-gray-900">{framework.name}</h3>
                          <span className={cn("text-2xl font-bold", getScoreColor(score))}>
                            {score}%
                          </span>
                        </div>
                        <Progress value={score} className="mb-2" />
                        <p className="text-sm text-gray-600">{framework.description}</p>
                        <div className="mt-4 flex justify-between items-center">
                          <span className="text-xs text-gray-500">Version {framework.version}</span>
                          <Button variant="outline" size="sm">
                            View Details
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>

            {/* Recent Assessments */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CheckSquare className="mr-2 h-5 w-5" />
                  Recent Assessments
                </CardTitle>
              </CardHeader>
              <CardContent>
                {assessmentsLoading ? (
                  <div className="text-center text-gray-500">Loading assessments...</div>
                ) : assessments.length === 0 ? (
                  <div className="text-center text-gray-500">No assessments found</div>
                ) : (
                  <div className="space-y-4">
                    {assessments.slice(0, 5).map((assessment) => {
                      const framework = frameworks.find(f => f.id === assessment.frameworkId);
                      return (
                        <div key={assessment.id} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-4">
                            <div className={cn(
                              "w-3 h-3 rounded-full",
                              assessment.status === "completed" ? "bg-green-500" :
                              assessment.status === "in_progress" ? "bg-yellow-500" : "bg-blue-500"
                            )} />
                            <div>
                              <h4 className="font-medium text-gray-900">{assessment.title}</h4>
                              <p className="text-sm text-gray-600">{framework?.name || "Unknown Framework"}</p>
                            </div>
                          </div>
                          <div className="flex items-center space-x-4">
                            <Badge variant="secondary" className={getStatusColor(assessment.status)}>
                              {assessment.status.replace('_', ' ')}
                            </Badge>
                            {assessment.score && (
                              <span className={cn("font-semibold", getScoreColor(assessment.score))}>
                                {assessment.score}%
                              </span>
                            )}
                            <span className="text-sm text-gray-500">
                              {new Date(assessment.createdAt).toLocaleDateString()}
                            </span>
                            <Button variant="ghost" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="frameworks" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Compliance Frameworks</CardTitle>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    Add Framework
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {frameworksLoading ? (
                  <div className="text-center text-gray-500">Loading frameworks...</div>
                ) : frameworks.length === 0 ? (
                  <div className="text-center text-gray-500">No frameworks found</div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {frameworks.map((framework) => (
                      <Card key={framework.id} className="border-l-4 border-l-primary">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div>
                              <h3 className="text-lg font-semibold text-gray-900">{framework.name}</h3>
                              <p className="text-sm text-gray-600 mt-1">{framework.description}</p>
                            </div>
                            <Badge variant={framework.isActive ? "default" : "secondary"}>
                              {framework.isActive ? "Active" : "Inactive"}
                            </Badge>
                          </div>
                          
                          <div className="space-y-2 mb-4">
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Version</span>
                              <span className="text-sm font-medium">{framework.version}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Compliance Score</span>
                              <span className={cn("text-sm font-medium", getScoreColor(getComplianceScore(framework.id)))}>
                                {getComplianceScore(framework.id)}%
                              </span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-gray-600">Requirements</span>
                              <span className="text-sm font-medium">
                                {Array.isArray(framework.requirements) ? framework.requirements.length : 0}
                              </span>
                            </div>
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm" className="flex-1">
                              <Eye className="mr-2 h-3 w-3" />
                              View
                            </Button>
                            <Button variant="outline" size="sm" className="flex-1">
                              <Edit className="mr-2 h-3 w-3" />
                              Edit
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assessments" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Compliance Assessments</CardTitle>
                  <Button>
                    <Plus className="mr-2 h-4 w-4" />
                    New Assessment
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assessment</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Framework</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Score</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Start Date</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Completed</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {assessmentsLoading ? (
                        <tr>
                          <td colSpan={7} className="px-6 py-4 text-center text-gray-500">Loading...</td>
                        </tr>
                      ) : assessments.length === 0 ? (
                        <tr>
                          <td colSpan={7} className="px-6 py-4 text-center text-gray-500">No assessments found</td>
                        </tr>
                      ) : (
                        assessments.map((assessment) => {
                          const framework = frameworks.find(f => f.id === assessment.frameworkId);
                          return (
                            <tr key={assessment.id}>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <div className="text-sm font-medium text-gray-900">{assessment.title}</div>
                                <div className="text-sm text-gray-500 truncate max-w-xs">{assessment.description}</div>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                                {framework?.name || "Unknown"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap">
                                <Badge variant="secondary" className={getStatusColor(assessment.status)}>
                                  {assessment.status.replace('_', ' ')}
                                </Badge>
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm">
                                {assessment.score ? (
                                  <span className={cn("font-medium", getScoreColor(assessment.score))}>
                                    {assessment.score}%
                                  </span>
                                ) : (
                                  <span className="text-gray-400">N/A</span>
                                )}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {assessment.startDate ? new Date(assessment.startDate).toLocaleDateString() : "Not started"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {assessment.completedDate ? new Date(assessment.completedDate).toLocaleDateString() : "-"}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                                <Button variant="ghost" size="sm">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button variant="ghost" size="sm">
                                  <Edit className="h-4 w-4" />
                                </Button>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
