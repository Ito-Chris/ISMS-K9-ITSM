import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { FileText, Download, Calendar, TrendingUp, BarChart3, PieChart, Activity } from "lucide-react";
import type { Incident, ServiceRequest, Asset, ComplianceAssessment } from "@shared/schema";

export default function Reports() {
  const [reportType, setReportType] = useState("summary");
  const [dateRange, setDateRange] = useState("30");

  // Fetch data for reports
  const { data: incidents = [] } = useQuery<Incident[]>({
    queryKey: ["/api/incidents"],
  });

  const { data: serviceRequests = [] } = useQuery<ServiceRequest[]>({
    queryKey: ["/api/service-requests"],
  });

  const { data: assets = [] } = useQuery<Asset[]>({
    queryKey: ["/api/assets"],
  });

  const { data: assessments = [] } = useQuery<ComplianceAssessment[]>({
    queryKey: ["/api/compliance-assessments"],
  });

  const { data: metrics } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  // Calculate report statistics
  const getDateRangeData = (items: any[], dateField: string) => {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - parseInt(dateRange));
    
    return items.filter(item => new Date(item[dateField]) >= cutoffDate);
  };

  const recentIncidents = getDateRangeData(incidents, 'createdAt');
  const recentRequests = getDateRangeData(serviceRequests, 'createdAt');

  const incidentsByStatus = {
    open: incidents.filter(i => i.status === 'open').length,
    in_progress: incidents.filter(i => i.status === 'in_progress').length,
    resolved: incidents.filter(i => i.status === 'resolved').length,
    closed: incidents.filter(i => i.status === 'closed').length,
  };

  const incidentsBySeverity = {
    critical: incidents.filter(i => i.severity === 'critical').length,
    high: incidents.filter(i => i.severity === 'high').length,
    medium: incidents.filter(i => i.severity === 'medium').length,
    low: incidents.filter(i => i.severity === 'low').length,
  };

  const assetsByType = {
    server: assets.filter(a => a.type === 'server').length,
    workstation: assets.filter(a => a.type === 'workstation').length,
    network_device: assets.filter(a => a.type === 'network_device').length,
    software: assets.filter(a => a.type === 'software').length,
    database: assets.filter(a => a.type === 'database').length,
  };

  const assetsByCriticality = {
    critical: assets.filter(a => a.criticality === 'critical').length,
    high: assets.filter(a => a.criticality === 'high').length,
    medium: assets.filter(a => a.criticality === 'medium').length,
    low: assets.filter(a => a.criticality === 'low').length,
  };

  const completedAssessments = assessments.filter(a => a.status === 'completed');
  const averageComplianceScore = completedAssessments.length > 0
    ? Math.round(completedAssessments.reduce((sum, a) => sum + (a.score || 0), 0) / completedAssessments.length)
    : 0;

  const reportData = {
    summary: {
      title: "Security Summary Report",
      description: "Overview of security metrics and trends",
      sections: [
        {
          title: "Key Metrics",
          data: [
            { label: "Active Incidents", value: metrics?.activeIncidents || 0, trend: "+3 from last period" },
            { label: "Open Service Requests", value: metrics?.openRequests || 0, trend: "No change" },
            { label: "Compliance Score", value: metrics?.complianceScore || "0%", trend: "+2% improvement" },
            { label: "Total Assets", value: assets.length, trend: `${assets.filter(a => a.status === 'active').length} active` },
          ]
        },
        {
          title: "Incident Analysis",
          data: [
            { label: "Critical Incidents", value: incidentsBySeverity.critical, color: "text-red-600" },
            { label: "High Priority", value: incidentsBySeverity.high, color: "text-yellow-600" },
            { label: "Medium Priority", value: incidentsBySeverity.medium, color: "text-blue-600" },
            { label: "Low Priority", value: incidentsBySeverity.low, color: "text-green-600" },
          ]
        }
      ]
    },
    incidents: {
      title: "Incident Analysis Report",
      description: `Detailed incident analysis for the last ${dateRange} days`,
      sections: [
        {
          title: "Status Distribution",
          data: Object.entries(incidentsByStatus).map(([status, count]) => ({
            label: status.replace('_', ' '),
            value: count
          }))
        },
        {
          title: "Severity Breakdown",
          data: Object.entries(incidentsBySeverity).map(([severity, count]) => ({
            label: severity,
            value: count
          }))
        }
      ]
    },
    assets: {
      title: "Asset Management Report",
      description: "Current asset inventory and status",
      sections: [
        {
          title: "Asset Types",
          data: Object.entries(assetsByType).map(([type, count]) => ({
            label: type.replace('_', ' '),
            value: count
          }))
        },
        {
          title: "Criticality Levels",
          data: Object.entries(assetsByCriticality).map(([level, count]) => ({
            label: level,
            value: count
          }))
        }
      ]
    },
    compliance: {
      title: "Compliance Report",
      description: "ISMS compliance status and assessment results",
      sections: [
        {
          title: "Assessment Overview",
          data: [
            { label: "Total Assessments", value: assessments.length },
            { label: "Completed", value: assessments.filter(a => a.status === 'completed').length },
            { label: "In Progress", value: assessments.filter(a => a.status === 'in_progress').length },
            { label: "Average Score", value: `${averageComplianceScore}%` },
          ]
        }
      ]
    }
  };

  const currentReport = reportData[reportType as keyof typeof reportData];

  const handleExport = () => {
    // In a real application, this would generate and download a report file
    console.log(`Exporting ${reportType} report for last ${dateRange} days`);
  };

  return (
    <div>
      {/* Page Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <nav className="flex mb-2" aria-label="Breadcrumb">
              <ol className="flex items-center space-x-2">
                <li className="text-gray-500 text-sm">Reports & Analytics</li>
                <li className="text-gray-500">/</li>
                <li className="text-gray-900 text-sm font-medium">Security Reports</li>
              </ol>
            </nav>
            <h2 className="text-2xl font-semibold text-gray-900">Security Reports</h2>
            <p className="text-gray-600 text-sm mt-1">Generate and view security reports and analytics</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={handleExport}>
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
            <Button>
              <Calendar className="mr-2 h-4 w-4" />
              Schedule Report
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Report Controls */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">Report Type:</label>
                <Select value={reportType} onValueChange={setReportType}>
                  <SelectTrigger className="w-48">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="summary">Security Summary</SelectItem>
                    <SelectItem value="incidents">Incident Analysis</SelectItem>
                    <SelectItem value="assets">Asset Management</SelectItem>
                    <SelectItem value="compliance">Compliance Report</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center space-x-2">
                <label className="text-sm font-medium text-gray-700">Date Range:</label>
                <Select value={dateRange} onValueChange={setDateRange}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7">Last 7 days</SelectItem>
                    <SelectItem value="30">Last 30 days</SelectItem>
                    <SelectItem value="90">Last 90 days</SelectItem>
                    <SelectItem value="365">Last year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Report Content */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center">
                  <FileText className="mr-2 h-5 w-5" />
                  {currentReport.title}
                </CardTitle>
                <p className="text-sm text-gray-600 mt-1">{currentReport.description}</p>
              </div>
              <Badge variant="outline" className="text-xs">
                Generated: {new Date().toLocaleString()}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-8">
              {currentReport.sections.map((section, sectionIndex) => (
                <div key={sectionIndex}>
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">{section.title}</h3>
                  
                  {reportType === 'summary' && sectionIndex === 0 ? (
                    // Key Metrics Grid
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                      {section.data.map((item, index) => (
                        <Card key={index}>
                          <CardContent className="p-4">
                            <div className="text-center">
                              <p className="text-2xl font-bold text-gray-900">{item.value}</p>
                              <p className="text-sm font-medium text-gray-700 mt-1">{item.label}</p>
                              <p className="text-xs text-gray-500 mt-2">{item.trend}</p>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  ) : reportType === 'summary' && sectionIndex === 1 ? (
                    // Incident Analysis Bar Chart
                    <div className="space-y-3">
                      {section.data.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <span className="text-sm font-medium text-gray-700">{item.label}</span>
                          <div className="flex items-center space-x-3">
                            <div className="w-32 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-600 h-2 rounded-full" 
                                style={{ width: `${Math.min((item.value / Math.max(...section.data.map(d => d.value))) * 100, 100)}%` }}
                              />
                            </div>
                            <span className={`text-sm font-bold ${item.color || 'text-gray-900'}`}>
                              {item.value}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    // Standard Data List
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {section.data.map((item, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                          <span className="text-sm font-medium text-gray-700 capitalize">{item.label}</span>
                          <span className="text-lg font-semibold text-gray-900">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {sectionIndex < currentReport.sections.length - 1 && (
                    <Separator className="mt-8" />
                  )}
                </div>
              ))}
            </div>

            {/* Report Footer */}
            <Separator className="my-8" />
            <div className="flex items-center justify-between text-sm text-gray-500">
              <div className="flex items-center space-x-4">
                <span>Report Period: Last {dateRange} days</span>
                <span>•</span>
                <span>Generated by ISMS K9 Security</span>
              </div>
              <div className="flex items-center space-x-2">
                <Activity className="h-4 w-4" />
                <span>Real-time data</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <BarChart3 className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Trend Analysis</h3>
                <p className="text-sm text-gray-600 mb-4">Analyze security trends over time</p>
                <Button variant="outline" className="w-full">
                  View Trends
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <PieChart className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Risk Assessment</h3>
                <p className="text-sm text-gray-600 mb-4">Comprehensive risk analysis</p>
                <Button variant="outline" className="w-full">
                  Generate Risk Report
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="text-center">
                <TrendingUp className="h-12 w-12 text-purple-600 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Executive Summary</h3>
                <p className="text-sm text-gray-600 mb-4">High-level security overview</p>
                <Button variant="outline" className="w-full">
                  Create Executive Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
