import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { 
  AlertTriangle, 
  Shield, 
  Ticket, 
  TrendingUp, 
  Download, 
  Plus,
  ArrowUp,
  ArrowDown,
  Minus,
  Clock,
  Users,
  FileText,
  Activity,
  CheckCircle,
  AlertCircle,
  Edit,
  Eye
} from "lucide-react";
import { cn } from "@/lib/utils";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import type { Incident, ServiceRequest, ComplianceAssessment } from "@shared/schema";

export default function Dashboard() {
  const [serviceRequestFilter, setServiceRequestFilter] = useState("all");
  const queryClient = useQueryClient();

  // Fetch dashboard metrics
  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["/api/dashboard/metrics"],
  });

  // Fetch recent incidents
  const { data: incidents = [], isLoading: incidentsLoading } = useQuery<Incident[]>({
    queryKey: ["/api/incidents"],
  });

  // Fetch service requests
  const { data: serviceRequests = [], isLoading: requestsLoading } = useQuery<ServiceRequest[]>({
    queryKey: ["/api/service-requests"],
  });

  // Fetch compliance assessments
  const { data: assessments = [], isLoading: assessmentsLoading } = useQuery<ComplianceAssessment[]>({
    queryKey: ["/api/compliance-assessments"],
  });

  const recentIncidents = incidents.slice(0, 5);
  const filteredRequests = serviceRequestFilter === "all" 
    ? serviceRequests.slice(0, 5)
    : serviceRequests.filter(r => r.status === serviceRequestFilter).slice(0, 5);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-destructive text-destructive-foreground";
      case "high": return "bg-yellow-500 text-white";
      case "medium": return "bg-blue-500 text-white";
      case "low": return "bg-green-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "resolved": return "bg-green-100 text-green-800";
      case "in_progress": return "bg-yellow-100 text-yellow-800";
      case "open": return "bg-blue-100 text-blue-800";
      case "closed": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "critical": return "bg-destructive text-destructive-foreground";
      case "high": return "bg-yellow-500 text-white";
      case "medium": return "bg-blue-500 text-white";
      case "low": return "bg-green-500 text-white";
      default: return "bg-gray-500 text-white";
    }
  };

  return (
    <div>
      {/* Dashboard Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <nav className="flex mb-2" aria-label="Breadcrumb">
              <ol className="flex items-center space-x-2">
                <li className="text-gray-500 text-sm">Security Management</li>
                <li className="text-gray-500">/</li>
                <li className="text-gray-900 text-sm font-medium">Dashboard</li>
              </ol>
            </nav>
            <h2 className="text-2xl font-semibold text-gray-900">Security Dashboard</h2>
            <p className="text-gray-600 text-sm mt-1">Monitor and manage your organization's security posture</p>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline">
              <Download className="mr-2 h-4 w-4" />
              Export Report
            </Button>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Incident
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Metrics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Active Incidents</p>
                  <p className="text-3xl font-semibold text-gray-900 mt-2">
                    {metricsLoading ? "..." : metrics?.activeIncidents || 0}
                  </p>
                  <p className="text-destructive text-sm mt-1 flex items-center">
                    <ArrowUp className="mr-1 h-3 w-3" />
                    +3 from last week
                  </p>
                </div>
                <div className="bg-red-100 p-3 rounded-lg">
                  <AlertTriangle className="text-destructive h-6 w-6" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Compliance Score</p>
                  <p className="text-3xl font-semibold text-gray-900 mt-2">
                    {metricsLoading ? "..." : metrics?.complianceScore || "0%"}
                  </p>
                  <p className="text-green-600 text-sm mt-1 flex items-center">
                    <ArrowUp className="mr-1 h-3 w-3" />
                    +2% from last month
                  </p>
                </div>
                <div className="bg-green-100 p-3 rounded-lg">
                  <Shield className="text-green-600 h-6 w-6" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Open Requests</p>
                  <p className="text-3xl font-semibold text-gray-900 mt-2">
                    {metricsLoading ? "..." : metrics?.openRequests || 0}
                  </p>
                  <p className="text-gray-600 text-sm mt-1 flex items-center">
                    <Minus className="mr-1 h-3 w-3" />
                    No change
                  </p>
                </div>
                <div className="bg-blue-100 p-3 rounded-lg">
                  <Ticket className="text-blue-600 h-6 w-6" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-gray-600 text-sm font-medium">Risk Score</p>
                  <p className="text-3xl font-semibold text-gray-900 mt-2">
                    {metricsLoading ? "..." : metrics?.riskScore || "Low"}
                  </p>
                  <p className="text-yellow-600 text-sm mt-1 flex items-center">
                    <AlertCircle className="mr-1 h-3 w-3" />
                    Requires attention
                  </p>
                </div>
                <div className="bg-yellow-100 p-3 rounded-lg">
                  <TrendingUp className="text-yellow-600 h-6 w-6" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
          {/* Recent Incidents */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg font-semibold">Recent Security Incidents</CardTitle>
                  <Button variant="link" className="text-primary">View All</Button>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ID</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Title</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Severity</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {incidentsLoading ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-gray-500">Loading...</td>
                        </tr>
                      ) : recentIncidents.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="px-6 py-4 text-center text-gray-500">No incidents found</td>
                        </tr>
                      ) : (
                        recentIncidents.map((incident) => (
                          <tr key={incident.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              #INC-{String(incident.id).padStart(4, '0')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{incident.title}</td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge className={getSeverityColor(incident.severity)}>
                                {incident.severity}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge variant="secondary" className={getStatusColor(incident.status)}>
                                {incident.status.replace('_', ' ')}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(incident.createdAt).toLocaleDateString()}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Compliance Overview */}
          <Card>
            <CardHeader className="pb-4">
              <CardTitle className="text-lg font-semibold">ISMS Compliance Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">ISO 27001</span>
                    <span className="text-sm text-gray-600">94%</span>
                  </div>
                  <Progress value={94} className="mt-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">NIST Framework</span>
                    <span className="text-sm text-gray-600">87%</span>
                  </div>
                  <Progress value={87} className="mt-2" />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">GDPR Compliance</span>
                    <span className="text-sm text-gray-600">92%</span>
                  </div>
                  <Progress value={92} className="mt-2" />
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div>
                <h4 className="text-sm font-medium text-gray-900 mb-3">Recent Assessments</h4>
                <div className="space-y-3">
                  {assessmentsLoading ? (
                    <div className="text-center text-gray-500">Loading...</div>
                  ) : assessments.length === 0 ? (
                    <div className="text-center text-gray-500">No assessments found</div>
                  ) : (
                    assessments.slice(0, 3).map((assessment) => (
                      <div key={assessment.id} className="flex items-center space-x-3">
                        <div className={cn(
                          "w-2 h-2 rounded-full",
                          assessment.status === "completed" ? "bg-green-500" :
                          assessment.status === "in_progress" ? "bg-yellow-500" : "bg-gray-400"
                        )} />
                        <div className="flex-1">
                          <p className="text-sm text-gray-900">{assessment.title}</p>
                          <p className="text-xs text-gray-500">
                            {assessment.status === "completed" ? "Completed" : 
                             assessment.status === "in_progress" ? "In Progress" : "Scheduled"} - {new Date(assessment.createdAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Service Requests */}
        <Card className="mb-6">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg font-semibold">Service Requests</CardTitle>
                <p className="text-sm text-gray-600 mt-1">Manage security-related service requests</p>
              </div>
              <div className="flex items-center space-x-3">
                <div className="flex items-center space-x-2">
                  <label className="text-sm text-gray-600">Filter:</label>
                  <Select value={serviceRequestFilter} onValueChange={setServiceRequestFilter}>
                    <SelectTrigger className="w-40">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Requests</SelectItem>
                      <SelectItem value="open">Open</SelectItem>
                      <SelectItem value="in_progress">In Progress</SelectItem>
                      <SelectItem value="resolved">Resolved</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button>
                  <Plus className="mr-2 h-4 w-4" />
                  New Request
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Request ID</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priority</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Due Date</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {requestsLoading ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-4 text-center text-gray-500">Loading...</td>
                    </tr>
                  ) : filteredRequests.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-6 py-4 text-center text-gray-500">No service requests found</td>
                    </tr>
                  ) : (
                    filteredRequests.map((request) => (
                      <tr key={request.id}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          #SR-{String(request.id).padStart(4, '0')}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{request.type.replace('_', ' ')}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge className={getPriorityColor(request.priority)}>
                            {request.priority}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <Badge variant="secondary" className={getStatusColor(request.status)}>
                            {request.status.replace('_', ' ')}
                          </Badge>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {request.dueDate ? new Date(request.dueDate).toLocaleDateString() : "No due date"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                          <Button variant="ghost" size="sm">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions and System Health */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                  <Plus className="text-primary h-6 w-6 mb-2" />
                  <span className="text-sm font-medium">Report Incident</span>
                </Button>
                <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                  <CheckCircle className="text-primary h-6 w-6 mb-2" />
                  <span className="text-sm font-medium">Start Assessment</span>
                </Button>
                <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                  <FileText className="text-primary h-6 w-6 mb-2" />
                  <span className="text-sm font-medium">Generate Report</span>
                </Button>
                <Button variant="outline" className="flex flex-col items-center p-4 h-auto">
                  <Users className="text-primary h-6 w-6 mb-2" />
                  <span className="text-sm font-medium">Manage Users</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg font-semibold">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-900">Security Monitoring</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    <span className="text-sm text-green-600">Active</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-900">Threat Intelligence</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    <span className="text-sm text-green-600">Updated</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-900">Backup Systems</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full" />
                    <span className="text-sm text-yellow-600">Warning</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-900">Network Security</span>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    <span className="text-sm text-green-600">Protected</span>
                  </div>
                </div>
              </div>
              
              <Separator className="my-6" />
              
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-900">Last Security Scan</span>
                  <span className="text-sm text-gray-600">2 hours ago</span>
                </div>
                <div className="mt-2">
                  <Button variant="link" className="text-primary p-0">Run Full System Scan</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
