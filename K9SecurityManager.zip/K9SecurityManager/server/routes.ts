import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertIncidentSchema, 
  insertServiceRequestSchema, 
  insertAssetSchema,
  insertComplianceFrameworkSchema,
  insertComplianceAssessmentSchema 
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // User routes
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  app.patch("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertUserSchema.partial().parse(req.body);
      const user = await storage.updateUser(id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Failed to update user", error });
    }
  });

  app.delete("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteUser(id);
      if (!deleted) {
        return res.status(404).json({ message: "User not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete user" });
    }
  });

  // Incident routes
  app.get("/api/incidents", async (req, res) => {
    try {
      const { status, severity } = req.query;
      let incidents;
      
      if (status) {
        incidents = await storage.getIncidentsByStatus(status as string);
      } else if (severity) {
        incidents = await storage.getIncidentsBySeverity(severity as string);
      } else {
        incidents = await storage.getAllIncidents();
      }
      
      res.json(incidents);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch incidents" });
    }
  });

  app.get("/api/incidents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const incident = await storage.getIncident(id);
      if (!incident) {
        return res.status(404).json({ message: "Incident not found" });
      }
      res.json(incident);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch incident" });
    }
  });

  app.post("/api/incidents", async (req, res) => {
    try {
      const incidentData = insertIncidentSchema.parse(req.body);
      const incident = await storage.createIncident(incidentData);
      res.status(201).json(incident);
    } catch (error) {
      res.status(400).json({ message: "Invalid incident data", error });
    }
  });

  app.patch("/api/incidents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertIncidentSchema.partial().parse(req.body);
      const incident = await storage.updateIncident(id, updates);
      if (!incident) {
        return res.status(404).json({ message: "Incident not found" });
      }
      res.json(incident);
    } catch (error) {
      res.status(400).json({ message: "Failed to update incident", error });
    }
  });

  app.delete("/api/incidents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteIncident(id);
      if (!deleted) {
        return res.status(404).json({ message: "Incident not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete incident" });
    }
  });

  // Service Request routes
  app.get("/api/service-requests", async (req, res) => {
    try {
      const { status } = req.query;
      let requests;
      
      if (status) {
        requests = await storage.getServiceRequestsByStatus(status as string);
      } else {
        requests = await storage.getAllServiceRequests();
      }
      
      res.json(requests);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service requests" });
    }
  });

  app.get("/api/service-requests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const request = await storage.getServiceRequest(id);
      if (!request) {
        return res.status(404).json({ message: "Service request not found" });
      }
      res.json(request);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch service request" });
    }
  });

  app.post("/api/service-requests", async (req, res) => {
    try {
      const requestData = insertServiceRequestSchema.parse(req.body);
      const request = await storage.createServiceRequest(requestData);
      res.status(201).json(request);
    } catch (error) {
      res.status(400).json({ message: "Invalid service request data", error });
    }
  });

  app.patch("/api/service-requests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertServiceRequestSchema.partial().parse(req.body);
      const request = await storage.updateServiceRequest(id, updates);
      if (!request) {
        return res.status(404).json({ message: "Service request not found" });
      }
      res.json(request);
    } catch (error) {
      res.status(400).json({ message: "Failed to update service request", error });
    }
  });

  app.delete("/api/service-requests/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteServiceRequest(id);
      if (!deleted) {
        return res.status(404).json({ message: "Service request not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete service request" });
    }
  });

  // Asset routes
  app.get("/api/assets", async (req, res) => {
    try {
      const { type } = req.query;
      let assets;
      
      if (type) {
        assets = await storage.getAssetsByType(type as string);
      } else {
        assets = await storage.getAllAssets();
      }
      
      res.json(assets);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch assets" });
    }
  });

  app.get("/api/assets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const asset = await storage.getAsset(id);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      res.json(asset);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch asset" });
    }
  });

  app.post("/api/assets", async (req, res) => {
    try {
      const assetData = insertAssetSchema.parse(req.body);
      const asset = await storage.createAsset(assetData);
      res.status(201).json(asset);
    } catch (error) {
      res.status(400).json({ message: "Invalid asset data", error });
    }
  });

  app.patch("/api/assets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertAssetSchema.partial().parse(req.body);
      const asset = await storage.updateAsset(id, updates);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      res.json(asset);
    } catch (error) {
      res.status(400).json({ message: "Failed to update asset", error });
    }
  });

  app.delete("/api/assets/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteAsset(id);
      if (!deleted) {
        return res.status(404).json({ message: "Asset not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete asset" });
    }
  });

  // Compliance Framework routes
  app.get("/api/compliance-frameworks", async (req, res) => {
    try {
      const frameworks = await storage.getAllComplianceFrameworks();
      res.json(frameworks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch compliance frameworks" });
    }
  });

  app.get("/api/compliance-frameworks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const framework = await storage.getComplianceFramework(id);
      if (!framework) {
        return res.status(404).json({ message: "Compliance framework not found" });
      }
      res.json(framework);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch compliance framework" });
    }
  });

  app.post("/api/compliance-frameworks", async (req, res) => {
    try {
      const frameworkData = insertComplianceFrameworkSchema.parse(req.body);
      const framework = await storage.createComplianceFramework(frameworkData);
      res.status(201).json(framework);
    } catch (error) {
      res.status(400).json({ message: "Invalid compliance framework data", error });
    }
  });

  // Compliance Assessment routes
  app.get("/api/compliance-assessments", async (req, res) => {
    try {
      const { frameworkId } = req.query;
      let assessments;
      
      if (frameworkId) {
        assessments = await storage.getAssessmentsByFramework(parseInt(frameworkId as string));
      } else {
        assessments = await storage.getAllComplianceAssessments();
      }
      
      res.json(assessments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch compliance assessments" });
    }
  });

  app.get("/api/compliance-assessments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const assessment = await storage.getComplianceAssessment(id);
      if (!assessment) {
        return res.status(404).json({ message: "Compliance assessment not found" });
      }
      res.json(assessment);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch compliance assessment" });
    }
  });

  app.post("/api/compliance-assessments", async (req, res) => {
    try {
      const assessmentData = insertComplianceAssessmentSchema.parse(req.body);
      const assessment = await storage.createComplianceAssessment(assessmentData);
      res.status(201).json(assessment);
    } catch (error) {
      res.status(400).json({ message: "Invalid compliance assessment data", error });
    }
  });

  app.patch("/api/compliance-assessments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertComplianceAssessmentSchema.partial().parse(req.body);
      const assessment = await storage.updateComplianceAssessment(id, updates);
      if (!assessment) {
        return res.status(404).json({ message: "Compliance assessment not found" });
      }
      res.json(assessment);
    } catch (error) {
      res.status(400).json({ message: "Failed to update compliance assessment", error });
    }
  });

  // Dashboard metrics endpoint
  app.get("/api/dashboard/metrics", async (req, res) => {
    try {
      const incidents = await storage.getAllIncidents();
      const serviceRequests = await storage.getAllServiceRequests();
      const assessments = await storage.getAllComplianceAssessments();
      
      const activeIncidents = incidents.filter(i => i.status !== 'resolved' && i.status !== 'closed').length;
      const openRequests = serviceRequests.filter(r => r.status !== 'resolved' && r.status !== 'closed').length;
      
      // Calculate compliance score (average of completed assessments)
      const completedAssessments = assessments.filter(a => a.status === 'completed' && a.score);
      const complianceScore = completedAssessments.length > 0 
        ? Math.round(completedAssessments.reduce((sum, a) => sum + (a.score || 0), 0) / completedAssessments.length)
        : 0;
      
      // Calculate risk score based on critical incidents
      const criticalIncidents = incidents.filter(i => i.severity === 'critical' && i.status !== 'resolved').length;
      let riskScore = 'Low';
      if (criticalIncidents > 5) riskScore = 'Critical';
      else if (criticalIncidents > 2) riskScore = 'High';
      else if (criticalIncidents > 0) riskScore = 'Medium';
      
      res.json({
        activeIncidents,
        complianceScore: `${complianceScore}%`,
        openRequests,
        riskScore
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard metrics" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
