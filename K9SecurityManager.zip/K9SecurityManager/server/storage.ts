import {
  users, incidents, serviceRequests, assets, complianceFrameworks, complianceAssessments,
  type User, type InsertUser,
  type Incident, type InsertIncident,
  type ServiceRequest, type InsertServiceRequest,
  type Asset, type InsertAsset,
  type ComplianceFramework, type InsertComplianceFramework,
  type ComplianceAssessment, type InsertComplianceAssessment
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // Incident methods
  getIncident(id: number): Promise<Incident | undefined>;
  createIncident(incident: InsertIncident): Promise<Incident>;
  updateIncident(id: number, updates: Partial<InsertIncident>): Promise<Incident | undefined>;
  deleteIncident(id: number): Promise<boolean>;
  getAllIncidents(): Promise<Incident[]>;
  getIncidentsByStatus(status: string): Promise<Incident[]>;
  getIncidentsBySeverity(severity: string): Promise<Incident[]>;

  // Service Request methods
  getServiceRequest(id: number): Promise<ServiceRequest | undefined>;
  createServiceRequest(request: InsertServiceRequest): Promise<ServiceRequest>;
  updateServiceRequest(id: number, updates: Partial<InsertServiceRequest>): Promise<ServiceRequest | undefined>;
  deleteServiceRequest(id: number): Promise<boolean>;
  getAllServiceRequests(): Promise<ServiceRequest[]>;
  getServiceRequestsByStatus(status: string): Promise<ServiceRequest[]>;

  // Asset methods
  getAsset(id: number): Promise<Asset | undefined>;
  createAsset(asset: InsertAsset): Promise<Asset>;
  updateAsset(id: number, updates: Partial<InsertAsset>): Promise<Asset | undefined>;
  deleteAsset(id: number): Promise<boolean>;
  getAllAssets(): Promise<Asset[]>;
  getAssetsByType(type: string): Promise<Asset[]>;

  // Compliance Framework methods
  getComplianceFramework(id: number): Promise<ComplianceFramework | undefined>;
  createComplianceFramework(framework: InsertComplianceFramework): Promise<ComplianceFramework>;
  updateComplianceFramework(id: number, updates: Partial<InsertComplianceFramework>): Promise<ComplianceFramework | undefined>;
  deleteComplianceFramework(id: number): Promise<boolean>;
  getAllComplianceFrameworks(): Promise<ComplianceFramework[]>;

  // Compliance Assessment methods
  getComplianceAssessment(id: number): Promise<ComplianceAssessment | undefined>;
  createComplianceAssessment(assessment: InsertComplianceAssessment): Promise<ComplianceAssessment>;
  updateComplianceAssessment(id: number, updates: Partial<InsertComplianceAssessment>): Promise<ComplianceAssessment | undefined>;
  deleteComplianceAssessment(id: number): Promise<boolean>;
  getAllComplianceAssessments(): Promise<ComplianceAssessment[]>;
  getAssessmentsByFramework(frameworkId: number): Promise<ComplianceAssessment[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private incidents: Map<number, Incident> = new Map();
  private serviceRequests: Map<number, ServiceRequest> = new Map();
  private assets: Map<number, Asset> = new Map();
  private complianceFrameworks: Map<number, ComplianceFramework> = new Map();
  private complianceAssessments: Map<number, ComplianceAssessment> = new Map();
  
  private currentUserId = 1;
  private currentIncidentId = 1;
  private currentServiceRequestId = 1;
  private currentAssetId = 1;
  private currentFrameworkId = 1;
  private currentAssessmentId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Create default admin user
    const adminUser: User = {
      id: this.currentUserId++,
      username: "admin",
      email: "admin@k9security.com",
      password: "admin123", // In production, this would be hashed
      firstName: "System",
      lastName: "Administrator",
      role: "admin",
      department: "IT Security",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create sample compliance frameworks
    const iso27001: ComplianceFramework = {
      id: this.currentFrameworkId++,
      name: "ISO 27001",
      description: "Information Security Management System standard",
      version: "2013",
      requirements: [
        { id: "A.5", title: "Information Security Policies" },
        { id: "A.6", title: "Organization of Information Security" },
        { id: "A.7", title: "Human Resource Security" },
        { id: "A.8", title: "Asset Management" }
      ],
      isActive: true,
      createdAt: new Date(),
    };
    this.complianceFrameworks.set(iso27001.id, iso27001);

    const nist: ComplianceFramework = {
      id: this.currentFrameworkId++,
      name: "NIST Cybersecurity Framework",
      description: "Framework for improving critical infrastructure cybersecurity",
      version: "1.1",
      requirements: [
        { id: "ID", title: "Identify" },
        { id: "PR", title: "Protect" },
        { id: "DE", title: "Detect" },
        { id: "RS", title: "Respond" },
        { id: "RC", title: "Recover" }
      ],
      isActive: true,
      createdAt: new Date(),
    };
    this.complianceFrameworks.set(nist.id, nist);
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const user: User = {
      ...insertUser,
      id: this.currentUserId++,
      createdAt: new Date(),
    };
    this.users.set(user.id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: number): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Incident methods
  async getIncident(id: number): Promise<Incident | undefined> {
    return this.incidents.get(id);
  }

  async createIncident(insertIncident: InsertIncident): Promise<Incident> {
    const incident: Incident = {
      ...insertIncident,
      id: this.currentIncidentId++,
      createdAt: new Date(),
      updatedAt: new Date(),
      resolvedAt: null,
    };
    this.incidents.set(incident.id, incident);
    return incident;
  }

  async updateIncident(id: number, updates: Partial<InsertIncident>): Promise<Incident | undefined> {
    const incident = this.incidents.get(id);
    if (!incident) return undefined;
    
    const updatedIncident = { 
      ...incident, 
      ...updates, 
      updatedAt: new Date(),
      resolvedAt: updates.status === 'resolved' ? new Date() : incident.resolvedAt
    };
    this.incidents.set(id, updatedIncident);
    return updatedIncident;
  }

  async deleteIncident(id: number): Promise<boolean> {
    return this.incidents.delete(id);
  }

  async getAllIncidents(): Promise<Incident[]> {
    return Array.from(this.incidents.values());
  }

  async getIncidentsByStatus(status: string): Promise<Incident[]> {
    return Array.from(this.incidents.values()).filter(incident => incident.status === status);
  }

  async getIncidentsBySeverity(severity: string): Promise<Incident[]> {
    return Array.from(this.incidents.values()).filter(incident => incident.severity === severity);
  }

  // Service Request methods
  async getServiceRequest(id: number): Promise<ServiceRequest | undefined> {
    return this.serviceRequests.get(id);
  }

  async createServiceRequest(insertRequest: InsertServiceRequest): Promise<ServiceRequest> {
    const request: ServiceRequest = {
      ...insertRequest,
      id: this.currentServiceRequestId++,
      createdAt: new Date(),
      updatedAt: new Date(),
      completedAt: null,
    };
    this.serviceRequests.set(request.id, request);
    return request;
  }

  async updateServiceRequest(id: number, updates: Partial<InsertServiceRequest>): Promise<ServiceRequest | undefined> {
    const request = this.serviceRequests.get(id);
    if (!request) return undefined;
    
    const updatedRequest = { 
      ...request, 
      ...updates, 
      updatedAt: new Date(),
      completedAt: updates.status === 'resolved' ? new Date() : request.completedAt
    };
    this.serviceRequests.set(id, updatedRequest);
    return updatedRequest;
  }

  async deleteServiceRequest(id: number): Promise<boolean> {
    return this.serviceRequests.delete(id);
  }

  async getAllServiceRequests(): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequests.values());
  }

  async getServiceRequestsByStatus(status: string): Promise<ServiceRequest[]> {
    return Array.from(this.serviceRequests.values()).filter(request => request.status === status);
  }

  // Asset methods
  async getAsset(id: number): Promise<Asset | undefined> {
    return this.assets.get(id);
  }

  async createAsset(insertAsset: InsertAsset): Promise<Asset> {
    const asset: Asset = {
      ...insertAsset,
      id: this.currentAssetId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.assets.set(asset.id, asset);
    return asset;
  }

  async updateAsset(id: number, updates: Partial<InsertAsset>): Promise<Asset | undefined> {
    const asset = this.assets.get(id);
    if (!asset) return undefined;
    
    const updatedAsset = { ...asset, ...updates, updatedAt: new Date() };
    this.assets.set(id, updatedAsset);
    return updatedAsset;
  }

  async deleteAsset(id: number): Promise<boolean> {
    return this.assets.delete(id);
  }

  async getAllAssets(): Promise<Asset[]> {
    return Array.from(this.assets.values());
  }

  async getAssetsByType(type: string): Promise<Asset[]> {
    return Array.from(this.assets.values()).filter(asset => asset.type === type);
  }

  // Compliance Framework methods
  async getComplianceFramework(id: number): Promise<ComplianceFramework | undefined> {
    return this.complianceFrameworks.get(id);
  }

  async createComplianceFramework(insertFramework: InsertComplianceFramework): Promise<ComplianceFramework> {
    const framework: ComplianceFramework = {
      ...insertFramework,
      id: this.currentFrameworkId++,
      createdAt: new Date(),
    };
    this.complianceFrameworks.set(framework.id, framework);
    return framework;
  }

  async updateComplianceFramework(id: number, updates: Partial<InsertComplianceFramework>): Promise<ComplianceFramework | undefined> {
    const framework = this.complianceFrameworks.get(id);
    if (!framework) return undefined;
    
    const updatedFramework = { ...framework, ...updates };
    this.complianceFrameworks.set(id, updatedFramework);
    return updatedFramework;
  }

  async deleteComplianceFramework(id: number): Promise<boolean> {
    return this.complianceFrameworks.delete(id);
  }

  async getAllComplianceFrameworks(): Promise<ComplianceFramework[]> {
    return Array.from(this.complianceFrameworks.values());
  }

  // Compliance Assessment methods
  async getComplianceAssessment(id: number): Promise<ComplianceAssessment | undefined> {
    return this.complianceAssessments.get(id);
  }

  async createComplianceAssessment(insertAssessment: InsertComplianceAssessment): Promise<ComplianceAssessment> {
    const assessment: ComplianceAssessment = {
      ...insertAssessment,
      id: this.currentAssessmentId++,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.complianceAssessments.set(assessment.id, assessment);
    return assessment;
  }

  async updateComplianceAssessment(id: number, updates: Partial<InsertComplianceAssessment>): Promise<ComplianceAssessment | undefined> {
    const assessment = this.complianceAssessments.get(id);
    if (!assessment) return undefined;
    
    const updatedAssessment = { ...assessment, ...updates, updatedAt: new Date() };
    this.complianceAssessments.set(id, updatedAssessment);
    return updatedAssessment;
  }

  async deleteComplianceAssessment(id: number): Promise<boolean> {
    return this.complianceAssessments.delete(id);
  }

  async getAllComplianceAssessments(): Promise<ComplianceAssessment[]> {
    return Array.from(this.complianceAssessments.values());
  }

  async getAssessmentsByFramework(frameworkId: number): Promise<ComplianceAssessment[]> {
    return Array.from(this.complianceAssessments.values()).filter(assessment => assessment.frameworkId === frameworkId);
  }
}

export const storage = new MemStorage();
